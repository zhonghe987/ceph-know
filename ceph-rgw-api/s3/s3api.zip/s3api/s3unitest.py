import unittest

ADMIN_ACCESS_KEY  =  "9DXOWU1HE84QW0WPE2S3"
ADMIN_SECRET_KEY  =  "9n3sJDW4mPKMlNIkC833Xug4vO7FjkrUIU8B2Uzv"
ACCESS_KEY  = "D673C77LPU5S1EICB3KL"
SECRET_KEY  = "7WC81mElj1Y2dmGUupnL3DJwXxJEZLl1AXZ4gEcL"
SERVER = '192.168.205.43'

class S3Api(unittest.TestCase):

   def test_bucket_create():
       pass
   
   def test_bucket_get()
       pass
   
   def test_bucket_delete()
       pass
 
  def test_bucket_location()
      pass
 
  def test_bucket_version()
      pass

  
